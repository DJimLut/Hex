
public class GameRunner extends Thread {
	private Player red;
	private Player blue;
	
	public GameRunner() {
		System.out.println("GameRunner class accessed.");
	}
	
	public void run() {
		
	}
}
