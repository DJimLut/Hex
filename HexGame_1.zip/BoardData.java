
public class BoardData {

}
