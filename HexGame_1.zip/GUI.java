import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GUI extends JFrame implements ActionListener {
	private static GUI frame;
	private JPanel gameSettings;
	private HexBoard activeGameBoard;	
	private JButton startButton = new JButton("Start Game");	
	
	private GameRunner runner;
	
	public GUI() {
		gameSettings = new JPanel();
		gameSettings.setPreferredSize(new Dimension(500, 500));
		gameSettings.add(startButton);
		
		startButton.addActionListener(this);	
		
		this.add(gameSettings);
	}
	
	public void startGame() {
		runner = new GameRunner();
		
		activeGameBoard = new HexBoard();
		activeGameBoard.setSize(1600, 800);		
		activeGameBoard.setLayout(new BorderLayout());
		
		this.getContentPane().remove(gameSettings);
		frame.setSize(1600, 800);
		frame.setLocation(200, 150);
		this.getContentPane().add(activeGameBoard);
		this.validate();
		this.repaint();
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == startButton) {
            startGame();
        }
	}
	
	public static void main(String[] args) {
		frame = new GUI();
		frame.setTitle("CSC445 Hex Game");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setLocation(200, 150);		
		
		frame.setVisible(true);
	}
}